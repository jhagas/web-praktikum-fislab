const { createClient } = require("@supabase/supabase-js");
require("dotenv").config();
var fs = require("fs");
let converter = require("json-2-csv");

var dir = "./nilai";

const { GoogleSpreadsheet } = require("google-spreadsheet");

// Read Docs for more info (what is "id" and "cred")
// https://www.npmjs.com/package/google-spreadsheet
const doc = new GoogleSpreadsheet(
  "id"
);
const creds = require("creds.json"); // imports json file

if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir);
}

function hitungNilai(nilai) {
  let hasil = 0;
  hasil += nilai.prelab * 45;
  hasil += nilai.abstrak * 5;
  hasil += nilai.pendahuluan_metodologi * 4;
  hasil += nilai.postlab * 30;
  hasil += nilai.kesimpulan * 4;
  hasil += nilai.format * 4;
  hasil += nilai.waktu * 80;
  hasil = hasil / 10;
  return hasil;
}

function compare(a, b) {
  if (a.profiles.nrp < b.profiles.nrp) {
    return -1;
  }
  if (a.profiles.nrp > b.profiles.nrp) {
    return 1;
  }
  return 0;
}

const url = process.env.SUPABASE_URL;
const skey = process.env.SERVICE_ROLE;
const supabase = createClient(url, skey);

async function nilai(kode_praktikum) {
  let aslab = await supabase
    .from("user_praktikum_linker")
    .select("profiles(full_name), kelompok")
    .eq("praktikum_role", "aslab")
    .eq("kode_praktikum", kode_praktikum);

  let { data } = await supabase
    .from("user_praktikum_linker")
    .select("profiles(full_name, nrp), kelompok, nilai")
    .eq("praktikum_role", "praktikan")
    .eq("kode_praktikum", kode_praktikum);

  let newData = data.sort(compare).map((d, i) => {
    const aslabKel = aslab.data.find(
      (element) => element.kelompok === d.kelompok
    );

    return {
      nama: d.profiles.full_name,
      nrp: d.profiles.nrp,
      kelompok: d.kelompok,
      nilai: hitungNilai(d.nilai),
      aslab: aslabKel.profiles.full_name,
    };
  });

  await doc.useServiceAccountAuth(creds);
  await doc.loadInfo(); // loads document properties and worksheets
  let sheet = doc.sheetsByTitle[kode_praktikum];
  if (sheet) await sheet.delete();

  const newSheet = await doc.addSheet({
    title: kode_praktikum,
    headerValues: ["nama", "nrp", "kelompok", "nilai", "aslab"],
  });

  const sheetData = await newSheet.addRows(newData);
}

for (let i = 1; i <= 6; i++) {
  nilai("I" + i);
}
// nilai("I1");
